
<!DOCTYPE html>
<html lang="en">

<head>




<style>body {
  font-family: Arial, sans-serif;
  background-color: #f2f2f2;
}

h1 {
  text-align: center;
  color: #333;
}

form {
			background-color: #fff;
			max-width: 400px;
			margin: 0 auto;
			padding: 20px;
			border-radius: 5px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
		}

label {
  display: block;
  margin-bottom: 10px;
  color: #333;
}

input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin-bottom: 20px;
}

input[type="submit"] {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #555;
}
p {
	color: red;
	margin-bottom: 20px;
		}
a {
    display: block;
	text-align: center;
	margin-top: 20px;
	color: #333;
	text-decoration: none;
		}
a:hover {
	color: #444;
		}
</style>
    <meta charset="UTF-8">
    <title>Login</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

    <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

    <link rel="stylesheet" href="css/login.css">

    <style type="text/css">
    #buttn {
        color: #fff;
        background-color: #5c4ac7;
    }
    </style>


    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    
    <link href="css/style.css" rel="stylesheet">

</head>




<body>
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
         <!--       <a class="navbar-brand" href="index.php"> <img class="img-rounded" src="images/logo.png" alt="" width="18%"> </a> -->
                <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                       

                        <?php
						if(empty($_SESSION["user_id"]))
							{
								
							}
						else
							{
									
									
										echo  '<li class="nav-item"><a href="your_orders.php" class="nav-link active">My Orders</a> </li>';
									echo  '<li class="nav-item"><a href="logout.php" class="nav-link active">Logout</a> </li>';
							}

						?>
                       


                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <div style=" background-image: url('images/croissant.jpg');">

        <?php
include("connection/connect.php"); 
error_reporting(0); 
session_start(); 
if(isset($_POST['submit']))  
{
	$username = $_POST['username'];  
	$password = $_POST['password'];
  

	if(!empty($_POST["submit"]))   
     {
	
									
  $loginquery ="SELECT * FROM staff WHERE username='$username' && password='".md5($password)."'     ";
	$result=mysqli_query($db, $loginquery);
	$row=mysqli_fetch_array($result);
	
	                        if(is_array($row))

								{
                  if( $row['type'] == 1){
                                $_SESSION["name"] = $row['name'];
									header("refresh:1;url=admin/dashboard.php");
                   // header('location:employee/employee.php');
            
	                            
                  }

                             elseif( $row['type'] == 2){
                              {
                                                    $_SESSION["employeename"] = $row['name'];
                                                    
                                                    
		 header("refresh:1;url=employee/employee.php");
                                                    $success=  "Login Successfully"; 
                    
                  
                                }
                              

                              }
                              else{
                                $message = "Invalid Username or Password!"; 
                              }  
                            }
              
      
	 
                                $loginquer ="SELECT * FROM users WHERE username='$username' && password='".md5($password)."'"; 
                                //selecting matching records
                                
                                 
                                $result=mysqli_query($db, $loginquer); //executing
                              
                                $rows=mysqli_fetch_array($result);
                              

if(is_array($rows)) 
{
            $_SESSION["user_id"] = $rows['u_id']; 
            $_SESSION["username"] = $rows['username']; 
            $_SESSION["last_name"] = $rows['l_name']; 


$id ="SELECT * FROM users WHERE u_id =  '".$_SESSION["user_id"]."' "; 

$res=mysqli_query($db, $id); //executing
$row=mysqli_fetch_array($result);


while($row=mysqli_fetch_array($res))
{

  $oid = "INSERT INTO orders (name,address, mobile, status) VALUES ('".$row['username']."', '".$row['address']."', '".$row['phone']."', '".$row['status']."')";
  mysqli_query($db, $oid);
  header("refresh:1;url=restaurants.php"); 

}


if(is_array($row)) 
{

  $message = "Invalid Username or Password!"; 
}
else
{  $success=  "Login Successfully"; 
      }

 
$id ="SELECT * FROM orders "; 

$resul=mysqli_query($db, $id); //executing


while($row=mysqli_fetch_array($resul))
{
         
  $_SESSION["o_id"] =$row['id']; 

}
         



}




     
}
     


}




	              
    


	 
	
	

     
  
?>


                <div class="module form-module">
                    <div class="toggle">

                    </div>
                    <div class="form">
                       
                        <span style="color:red;"><?php echo $message; ?></span>
                        <span style="color:green;"><?php echo $success; ?></span>
                        <!--<form action="" method="post">
                            <input type="text" placeholder="Username" name="username" />
                            <input type="password" placeholder="Password" name="password" />
                            <input type="submit" id="buttn" name="submit" value="Login" />
                        </form>-->

                        <form method="post">
    <label> Username:</label>
    <input type="text" placeholder="Username" name="username" />
    <label>Password:</label>
  <input type="password" placeholder="Password" name="password" />
  <input type="submit" id="buttn" name="submit" value="Login" />
    
  </form>

  
  <a href="registration.php">Don't have an account?  Register here</a>


                        
                    </div>


                    

                   
                </div>
                <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>


                


                <div class="container-fluid pt-3">
                    <p></p>
                </div>



                <?php include "include/footer.php" ?>



</body>

</html>